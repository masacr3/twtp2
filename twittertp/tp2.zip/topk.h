#include "cmk.h"

//Funcion de comparacion del heap
int cmp_heap(const void* a, const void* b);

//Hace el top k
void top_k(datos_t* d, int k, int tam_datos);
