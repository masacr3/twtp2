#include <string.h>

int hashing1(const char* cp);
int hashing2(const char* key);
int hashing3(const char* s);
int hashing4(const char* cp);