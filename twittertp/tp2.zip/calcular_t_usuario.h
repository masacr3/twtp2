#include "hash.h"
void mostrar_hash(hash_t* reverse);
hash_t* calcular_t_usuarios(char* archivo, int* cant_e);