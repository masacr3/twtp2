#ifndef COUNTINGSORT_H
#define COUNTINGSORT_H

#include "data_pu.h"

void countingsort_numero(data_t* pp, int n, int max, int min);


#endif